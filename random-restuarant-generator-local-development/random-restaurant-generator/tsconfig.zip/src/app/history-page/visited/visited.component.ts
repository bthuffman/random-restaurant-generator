import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visited',
  templateUrl: './visited.component.html',
  styleUrls: ['./visited.component.css']
})
export class VisitedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
