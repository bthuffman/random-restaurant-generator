import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RandomizerComponent } from './randomizer/randomizer.component';
import { ResultsPageComponent } from './results-page/results-page.component';
import { LoginComponent } from './auth/login/login.component';
import { SignUpComponent } from './auth/sign-up/sign-up.component';
import { HistoryPageComponent } from './history-page/history-page.component';
import { FavoritedComponent } from './favorited/favorited.component';

//defines routes
 const routes: Routes = [
     //The navigationComponent is acting as a welcome page here, may want to switch for the Randomizer component when pushed. 
     { path: '', component: RandomizerComponent},
     { path: 'results-page', component: ResultsPageComponent},
     { path: 'login', component: LoginComponent},
     { path: 'sign-up', component: SignUpComponent},
     { path: 'history', component: HistoryPageComponent},
     { path: 'favorites', component: FavoritedComponent}
 ] 
@NgModule ({
   //Informs angular about the routes. reaching out to the RouterModule and passing the routes array as an arguement. 
    imports: [RouterModule.forRoot(routes)],
    //Used to expose modules to each other.
    exports: [RouterModule],
    providers: []
})
export class AppRoutingModule {}