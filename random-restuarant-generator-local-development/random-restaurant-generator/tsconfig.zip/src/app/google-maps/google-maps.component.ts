import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { MapsAPILoader, MouseEvent } from '@agm/core';
import { FindGoogleDayService } from '../find-google-day.service';

@Component({
  selector: 'app-google-maps',
  templateUrl: './google-maps.component.html',
  styleUrls: ['./google-maps.component.css']
})

export class GoogleMapsComponent implements OnInit {
  zoom: number;
  private geoCoder;

  //details about restaurant
  latitude: number;
  longitude: number;
  address: string;
  name: string;
  id;
  details;
  phoneNumber;
  website;
  ratings;
  //review variables
  review;
  reviewAspectRating;
  reviewAspectType;
  reviewAuthor;
  reviewAuthorUrl;
  reviewText;
  //OpeningHours interface
  open;
  isOpen;
  openTime;
  weekday;
  weekdays;

  //These variables are for the random selection of a restaurant 
  //This section is for the nearby search
  newService;
  request = {
    location: {
      lat: 35.096887,
      lng: -106.654439
    },
    radius: 50000,
    keyword: 'food'
  };
  googleDay: number;
  //This section is for the details results
  detailsRequest;
  newPlace;
  placeDetails: ;
  newResults;

  @ViewChild('search')
  // ElementRef is a wrapper around a native element inside of a View. Allows you to use Angular templates and data binding to access DOM elements without reference to the native element.
  public searchElementRef: ElementRef;

  //randomizer button
  @ViewChild('randomButton')

  public randomElementRef: ElementRef;

  constructor(
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    //Inject/pass an instance of the find-google-day service
    private googleDayService : FindGoogleDayService
  ) {   }

  //A lifecycle hook that is called after Angular has initialized all data-bound properties of a directive. Used to handle any additional initialization tasks.
  ngOnInit() {

    //load Places Autocomplete
    this.mapsAPILoader.load().then(() => {

      //assign geoCoder a new Geocoder object
      this.geoCoder = new google.maps.Geocoder;

      // This is the latitude and longitude of 10 miles 0.14492753623 
      var tenMileLatLong = 0.14492753623;

      //used for the let service autocomplete options
      var defaultBounds = new google.maps.LatLngBounds(
        {
          lat: this.latitude - tenMileLatLong,
          lng: this.longitude - tenMileLatLong
        },
        {
          lat: this.latitude + tenMileLatLong,
          lng: this.longitude + tenMileLatLong
        });

      var options = {
        bounds: defaultBounds,
        types: ['establishment']
      };

      //for the search box
      var input = this.searchElementRef.nativeElement;

      let service = new google.maps.places.Autocomplete(input, options);

      //this runs if a search is made in the search box
      service.addListener("place_changed", () => {
        //ngZone is necessary to update the marker position based on the result 
        this.ngZone.run(() => {

        //get the place result
        let place: google.maps.places.PlaceResult = service.getPlace();

        //verify result
        if (place.geometry === undefined || place.geometry === null) {
          return;
        }
        console.log(place);


        
        //this.googleDayService.printToConsole("Hello this is the service");

        //set latitude, longitude, name and placeid
        this.latitude = place.geometry.location.lat();
        this.longitude = place.geometry.location.lng();
        this.name = place.name;
        this.ratings = place.rating
        this.id = place.id;
        this.address = place.formatted_address;
        this.phoneNumber = place.formatted_phone_number;
        this.website = place.website;
        //OpeningHours interface
          //acquire the day user is using app to acquire relevant hours of operation information
          let googleDay = 0;
          this.open = place.opening_hours.open_now;
          this.opened(this.open);
          ;
          this.weekday = place.opening_hours.weekday_text[googleDay];
          this.weekdays = place.opening_hours.weekday_text;


        //PlaceReview interface
          this.reviewAuthor = place.reviews[0].author_name;
          this.reviewAuthorUrl = place.reviews[0].author_url;
          this.reviewText = place.reviews[0].text;
          //essential to allowing access for the PlaceResults PlaceAspectRatings[ratings, type]. 
          this.review = place.reviews[0]
          this.reviewAspectRating = this.review.rating;
          this.reviewAspectType = this.review.type;

      });
    });
      this.setCurrentLocation(service);
    });
  }

  //Allows for a determination about whether the current restaurant is opened or not to deliver that to the html
  public opened(open){
    if (open === true) {
      this.openTime = "Open";
    } else if (open === false) {
      this.openTime = "Closed";
    } else {
      console.log("There is an error or this location doesn't have an open_now value as part of the PlaceResults[].");
    } 
  }


  // Get Current Location Coordinates 
  private setCurrentLocation(service) {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.latitude = position.coords.latitude;
        this.longitude = position.coords.longitude;
        this.zoom = 14;
        this.getAddress(this.latitude, this.longitude);
        var geolocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        var circle = new google.maps.Circle(
          { center: geolocation, radius: position.coords.accuracy });
        service.setBounds(circle.getBounds());
      });
    }
  }

  //Allows user to drag the google map marker to select a different location/address.
  markerDragEnd($event: MouseEvent) {
    this.latitude = $event.coords.lat;
    this.longitude = $event.coords.lng;
    this.getAddress(this.latitude, this.longitude);
  }

  //Used to acquire the actual address of the searched or moved location
  getAddress(latitude, longitude) {
    //ngZone is necessary to update the marker position in a timely manner
    this.ngZone.run(() => {
    this.geoCoder.geocode({ 'location': { lat: latitude, lng: longitude } }, (results, status) => {
    
      if (status === 'OK') {
        if (results[0]) {
          // this.name = results[0].name;
          // this.ratings = results[0].rating;
          // this.id = results[0].id;
          this.address = results[0].formatted_address;
          // this.phoneNumber = results[0].formatted_phone_number;
          // this.website = results[0].website;
          // //OpeningHours interface
          //   //acquire the day user is using app to acquire relevant hours of operation information
          //   let googleDay = 0;
          //   this.open = results[0].opening_hours.open_now;
          //   this.opened(this.open);
          //   this.weekday = results[0].opening_hours.weekday_text[googleDay];
          //   this.weekdays = results[0].opening_hours.weekday_text;


          // //PlaceReview interface
          //   this.reviewAuthor = results[0].reviews[0].author_name;
          //   this.reviewAuthorUrl = results[0].reviews[0].author_url;
          //   this.reviewText = results[0].reviews[0].text;
          //   //essential to allowing access for the PlaceResults PlaceAspectRatings[ratings, type]. 
          //   this.review = results[0].reviews[0]
          //   this.reviewAspectRating = this.review.rating;
          //   this.reviewAspectType = this.review.type;
          
        } else {
          window.alert('No results found');
        }
      } else {
        window.alert('Geocoder failed due to: ' + status);
      }
    });
    });
  }

  //for randomly selecting a restaurant
  randomSelection() { 
    // Callback is function, the anonymous function is used to pass "this" to itself (the Component). This is the highest object in scope, without it this wouldn't refer to the component but would be limited to it's own scope. 
    var newService = new google.maps.places.PlacesService(this.randomElementRef.nativeElement).nearbySearch(this.request, (result, status) => this.nearbyCallback(result, status, this))
    // console.log(Component.newService)
    // let newPlace: google.maps.places.PlaceResult = this.newService.getDetails();
    // // console.log(service);
    // console.log(newPlace)
  };

  nearbyCallback(nearbyResults: google.maps.places.PlaceResult[], nearbyStatus: google.maps.places.PlacesServiceStatus, Component: GoogleMapsComponent) {
    //ngZone is necessary to update the marker position and restaurant info based on the result 
    this.ngZone.run(() => {
    if (nearbyStatus == google.maps.places.PlacesServiceStatus.OK) {

      //get the length of the PlaceResults[]. Appears to always be 19
      let max = nearbyResults.length - 1;

      //select a random number based on the length of the PlaceResults[]
      let randomNumber = Math.floor(Math.random() * Math.floor(max));

      //set's the service = to the restaurant at the randomNumber index
      let service = nearbyResults[randomNumber];

      // console.log(Component.newService)
      // let newPlace: google.maps.places.PlaceResult = this.newService.getDetails();
      // // console.log(service);
      // console.log(newPlace);

      //For displaying the restaurant name and assigning it an id for the placeDetails search
      this.name = service.name;
      this.id = service.id;

      this.detailsRequest = {
        placeId: this.id
      }

      // Component.reviewAuthor = service.reviews[0].author_name;
      // console.log(this.reviewAuthor);

      this.newService.getDetails(this.detailsRequest , (result, status) => this.detailsCallback(result, status, this))

      //PlaceReview interface
      //   Component.reviewAuthor = newPlace.reviews[0].author_name;
      //   Component.reviewAuthorUrl = newPlace.reviews[0].author_url;
      //   Component.reviewText = newPlace.reviews[0].text;
      //   //essential to allowing access for the PlaceResults PlaceAspectRatings[ratings, type]. 
      //   Component.review = newPlace.reviews[0]
      //   Component.reviewAspectRating = Component.review.rating;
      //   Component.reviewAspectType = Component.review.type;
        
      // // //verify result
      // if (newPlace.geometry === undefined || newPlace.geometry === null) {
      //   return;
      // }

      
      // //set latitude and longitude
      Component.latitude = service.geometry.location.lat();
      Component.longitude = service.geometry.location.lng();
      
      Component.getAddress(Component.latitude, Component.longitude);
    }
    });
  }
  
  detailsCallback(results: google.maps.places.PlaceResult, status: google.maps.places.PlacesServiceStatus, Component: GoogleMapsComponent) {
    //ngZone is necessary to update the marker position and restaurant info based on the result 
    this.ngZone.run(() => {
      if (status == google.maps.places.PlacesServiceStatus.OK) {
        let newResults = results;
        console.log("Made it to detailsCallback");
        console.log(Component.newPlace);
        Component.id = newResults.id;
        // Component.address = newPlace.formatted_address;
        this.phoneNumber = newResults.formatted_phone_number;
        Component.website = newResults.website;
        //OpeningHours interface
          //acquire the day user is using app to acquire relevant hours of operation information
          let googleDay = 0;
          Component.open = newResults.opening_hours.open_now;
          Component.opened(this.open);
          // Component.weekday = newPlace.opening_hours.weekday_text[googleDay];
          Component.weekdays = newResults.opening_hours.weekday_text;
      } else {
        console.log("It broke at the details callback, places service status is not ok.");
      }
    });
  }

}
//services declare servvices in the beinging. 