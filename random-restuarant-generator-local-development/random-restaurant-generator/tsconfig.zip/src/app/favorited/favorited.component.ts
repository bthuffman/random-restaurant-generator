import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-favorited',
  templateUrl: './favorited.component.html',
  styleUrls: ['./favorited.component.css']
})
export class FavoritedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
