import { Injectable } from '@angular/core';

//tells angular that this is a service
@Injectable({
  providedIn: 'root'
})
export class FindGoogleDayService {

  constructor() { }

  printToConsole(arg){
    console.log(arg);
  }

}
